#Capitani | Soluções em TI, Recrutamento e Seleção


Sistema de cadastro com permissões para usuários



### Frameworks/Bibliotecas
* [bcit-ci/CodeIgniter](https://github.com/bcit-ci/CodeIgniter)
* [twbs/bootstrap](https://github.com/twbs/bootstrap) 
* [jquery/jquery](https://github.com/jquery/jquery) 
* [jquery/jquery-ui](https://github.com/jquery/jquery-ui) 

### Requerimento
* PHP 5.6.0
* MySQL

### Desenvolvido
* Renato Lessa - renatolessa.2011@hotmail.com / contato@relesi.com.br
